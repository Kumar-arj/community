# community

community.v7lancers.com

#######
Hosting details :
######

MySQL Info :

PhpMyAdmin URL : https://auth-db287.hostinger.com/

DB Name 	:  	u945823703_community 
User Name	:	u945823703_community
Password	 : 	v7community

FTP Details :

UserName	:	u945823703.community
Host 		:	ftp.v7lancers.com
Password 	:	v7community
	


