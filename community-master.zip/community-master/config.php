<?php

$connection = mysqli_connect("localhost",'u945823703_community','v7community','u945823703_community');

if(!$connection) {
	die("Unable to connect" . mysqli_error($connection));
}

?>