<?php
include 'config.php';
if (isset($_POST['register'])) {
        $applicant_name = $_POST['applicant_name'];
        $dob = $_POST['dob'];
        $degree = $_POST['degree'];
        $year = $_POST['year'];
        $institution = addslashes($_POST['institution']);
        $ugper = $_POST['ugper'];
        $noofworkshopsorg = addslashes($_POST['noofworkshopsorg']);
        $noofworkshopsatt = addslashes($_POST['noofworkshopsatt']);
        $achievements = addslashes($_POST['achievements']);
        $certifications = addslashes($_POST['certifications']);
        $professionalmembership = addslashes($_POST['professionalmembership']);
        $socialactivity = addslashes($_POST['socialactivity']);
        $resourceperson = addslashes($_POST['resourceperson']);
        $phno = $_POST['phno'];
        $email = $_POST['email'];
        $dept = $_POST['dept'];
        // $source       = $_FILES["uploadFile"]["name"];  
        // $tmp_source = $_FILES["uploadFile"]["tmp_name"];
        // move_uploaded_file( $tmp_source, "resume/$source" );
        $h_image = $_FILES['uploadFile']['name'];
        $tmp_image = $_FILES['uploadFile']['tmp_name'];
        if($tmp_image != ""){
        $filename   = uniqid() . "_" . time();
        $mime = mime_content_type($tmp_image);
        echo $mime;
        $extension  = pathinfo($h_image, PATHINFO_EXTENSION);
        echo $extension;
        $basename   = $filename . '.' . $extension;
        move_uploaded_file($tmp_image, "resume/$basename");
        }
        else{
            $basename = "Not Uploaded";
        }
        $query = "INSERT INTO student_ambassador(applicant_name,applicant_dob,applicant_degree,applicant_year,applicant_dept,applicant_institution,ugper,noofworkshopsorg,noofworkshopsatt,achievements,certifications,professionalmembership,socialactivity,resourceperson,applicant_phno,applicant_email,applicant_resume) VALUES('$applicant_name', '$dob', '$degree', '$year','$dept','$institution','$ugper','$noofworkshopsorg','$noofworkshopsatt','$achievements','$certifications','$professionalmembership','$socialactivity','$resourceperson','$phno','$email','$basename')";
        $insert_query = mysqli_query($connection,$query);
        if (!$insert_query) {
            die("Query Failed" . mysqli_error($connection));
        }
       header("Location: thankyou.html");
}

?>
